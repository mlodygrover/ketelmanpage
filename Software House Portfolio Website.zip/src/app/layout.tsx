import type { Metadata } from "next";
import "../styles/index.css";

export const metadata: Metadata = {
  title: {
    default: "Ketelman Holding & Software House - Doświadczenie w Rozwoju Oprogramowania",
    template: "%s | Ketelman Holding & Software House",
  },
  description:
    "Ketelman Holding & Software House to firma programistyczna z wieloletnim doświadczeniem w tworzeniu systemów komercyjnych. Tworzymy aplikacje webowe, mobilne i systemy SaaS sprawdzone w prawdziwym biznesie.",
  keywords: [
    "software house",
    "tworzenie oprogramowania",
    "aplikacje webowe",
    "aplikacje mobilne",
    "systemy SaaS",
    "rozwój aplikacji",
    "programowanie",
    "React",
    "Next.js",
    "Node.js",
    "e-commerce",
    "CRM",
    "systemy biznesowe",
  ],
  authors: [{ name: "Ketelman Holding & Software House" }],
  creator: "Ketelman Holding & Software House",
  publisher: "Ketelman Holding & Software House",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://ketelman.com"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Ketelman Holding & Software House - Doświadczenie w Rozwoju Oprogramowania",
    description:
      "Software house z wieloletnim doświadczeniem w tworzeniu własnych systemów komercyjnych. Przekuwamy wiedzę biznesową w innowacyjne rozwiązania dla Twojej firmy.",
    url: "https://ketelman.com",
    siteName: "Ketelman Holding & Software House",
    locale: "pl_PL",
    type: "website",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Ketelman Holding & Software House",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Ketelman Holding & Software House - Doświadczenie w Rozwoju Oprogramowania",
    description:
      "Software house z wieloletnim doświadczeniem w tworzeniu własnych systemów komercyjnych.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "google-site-verification-code",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pl">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Ketelman Holding & Software House",
              description:
                "Software house specjalizujący się w tworzeniu aplikacji webowych, mobilnych i systemów SaaS z wieloletnim doświadczeniem biznesowym.",
              url: "https://ketelman.com",
              logo: "https://ketelman.com/logo.png",
              address: {
                "@type": "PostalAddress",
                addressLocality: "Warszawa",
                addressCountry: "PL",
              },
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+48-123-456-789",
                contactType: "customer service",
                availableLanguage: ["pl", "en"],
              },
              sameAs: [
                "https://linkedin.com/company/ketelman",
                "https://github.com/ketelman",
                "https://twitter.com/ketelman",
              ],
              areaServed: {
                "@type": "GeoCircle",
                geoMidpoint: {
                  "@type": "GeoCoordinates",
                  latitude: "52.2297",
                  longitude: "21.0122",
                },
                geoRadius: "1000000",
              },
              serviceType: [
                "Web Development",
                "Mobile App Development",
                "SaaS Solutions",
                "E-commerce Development",
                "Custom Software Development",
              ],
            }),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
