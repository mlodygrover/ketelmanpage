import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { Advantages } from "./components/Advantages";
import { Portfolio } from "./components/Portfolio";
import { Process } from "./components/Process";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <section id="home">
          <Hero />
        </section>
        <section id="advantages">
          <Advantages />
        </section>
        <section id="portfolio">
          <Portfolio />
        </section>
        <section id="process">
          <Process />
        </section>
        <section id="contact">
          <Contact />
        </section>
      </main>
      <Footer />
    </div>
  );
}
