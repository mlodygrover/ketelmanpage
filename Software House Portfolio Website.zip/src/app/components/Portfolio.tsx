"use client";

import { ShoppingCart, LineChart, Smartphone, Globe, Calendar, Package } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const projects = [
  {
    icon: ShoppingCart,
    title: "E-commerce Platform",
    category: "Handel online",
    description: "Kompleksowa platforma sprzedażowa obsługująca 50,000+ transakcji miesięcznie. System zarządzania magazynem, integracje płatności i zaawansowana analityka sprzedaży.",
    technologies: ["React", "Node.js", "PostgreSQL", "Stripe"],
    metrics: {
      users: "25k+ użytkowników",
      performance: "99.9% uptime",
      growth: "+180% wzrost ROI"
    },
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: LineChart,
    title: "Business Intelligence Dashboard",
    category: "Analityka biznesowa",
    description: "System raportowania i wizualizacji danych w czasie rzeczywistym dla zarządu. Integracja z 15+ źródłami danych, predykcje AI i automatyczne raporty.",
    technologies: ["Python", "React", "TensorFlow", "BigQuery"],
    metrics: {
      users: "Poziom enterprise",
      performance: "Real-time data",
      growth: "70% oszczędność czasu"
    },
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: Smartphone,
    title: "Mobile CRM",
    category: "Zarządzanie klientami",
    description: "Aplikacja mobilna do zarządzania relacjami z klientami dla zespołów sprzedażowych. Offline-first, synchronizacja, geolokalizacja i integracje z systemami ERP.",
    technologies: ["React Native", "Firebase", "GraphQL"],
    metrics: {
      users: "500+ handlowców",
      performance: "4.8★ ocena",
      growth: "+45% efektywność"
    },
    gradient: "from-green-500 to-emerald-500"
  },
  {
    icon: Globe,
    title: "SaaS Marketing Platform",
    category: "Marketing automation",
    description: "Platforma automatyzacji marketingu z AI. Email campaigns, segmentacja, A/B testing i personalizacja treści dla tysięcy kampanii.",
    technologies: ["Next.js", "AWS", "Redis", "OpenAI"],
    metrics: {
      users: "10k+ firm",
      performance: "2M+ emaili/dzień",
      growth: "Skala globalna"
    },
    gradient: "from-orange-500 to-red-500"
  },
  {
    icon: Calendar,
    title: "Booking & Scheduling System",
    category: "Rezerwacje online",
    description: "System rezerwacji i zarządzania kalendarzem dla branży usługowej. Płatności online, przypomnienia SMS, integracja z Google Calendar.",
    technologies: ["Vue.js", "Laravel", "MySQL", "Twilio"],
    metrics: {
      users: "150+ lokalizacji",
      performance: "20k+ rezerwacji/m-c",
      growth: "+200% więcej wizyt"
    },
    gradient: "from-indigo-500 to-purple-500"
  },
  {
    icon: Package,
    title: "Warehouse Management System",
    category: "Logistyka",
    description: "Zaawansowany system WMS z optymalizacją tras, skanowaniem kodów, automatycznym uzupełnianiem stanów i integracją z kurierami.",
    technologies: ["Angular", "Django", "PostgreSQL", "IoT"],
    metrics: {
      users: "5 magazynów",
      performance: "15k+ produktów",
      growth: "60% szybciej"
    },
    gradient: "from-yellow-500 to-orange-500"
  }
];

export function Portfolio() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-50 to-white text-slate-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block px-4 py-2 bg-cyan-100 border border-cyan-300 rounded-full text-cyan-700 text-sm mb-4"
          >
            Portfolio
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl mb-4 text-slate-900"
          >
            Zrealizowane projekty komercyjne
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-slate-600 max-w-3xl mx-auto"
          >
            Każdy z tych systemów działa w produkcji, generuje przychody i obsługuje prawdziwych użytkowników. 
            To nie są demo - to <span className="text-cyan-600">nasze własne firmy</span>.
          </motion.p>
        </div>

        {/* Image gallery */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid md:grid-cols-2 gap-6 mb-16"
        >
          <div className="relative h-80 rounded-2xl overflow-hidden group">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1652212976547-16d7e2841b8c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRpZ2l0YWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2NzYyODYzM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Technology"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-purple-900/70 via-transparent to-cyan-900/70 opacity-60"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-3xl mb-2 text-white">Zaawansowane technologie</h3>
                <p className="text-slate-200">AI, Big Data, Cloud Computing</p>
              </div>
            </div>
          </div>
          <div className="relative h-80 rounded-2xl overflow-hidden group">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1620570625542-194933f7639a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzZXJ2ZXIlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2NzY1MTgwM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Infrastructure"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-900/70 via-transparent to-purple-900/70 opacity-60"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <h3 className="text-3xl mb-2 text-white">Niezawodna infrastruktura</h3>
                <p className="text-slate-200">Skalowalna architektura serwerowa</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => {
            const Icon = project.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card 
                  className="bg-white border-slate-200 hover:border-slate-300 p-8 transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/10 group h-full"
                >
                  <div className="flex items-start gap-4 mb-6">
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${project.gradient} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <Badge className="mb-2 bg-slate-100 text-slate-700 border-slate-200">
                        {project.category}
                      </Badge>
                      <h3 className="text-2xl text-slate-900">
                        {project.title}
                      </h3>
                    </div>
                  </div>

                  <p className="text-slate-600 mb-6 leading-relaxed">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech, i) => (
                      <span 
                        key={i}
                        className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm border border-slate-200"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-200">
                    <div>
                      <div className="text-sm text-slate-500 mb-1">Użytkownicy</div>
                      <div className="text-slate-900">{project.metrics.users}</div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-500 mb-1">Wydajność</div>
                      <div className="text-slate-900">{project.metrics.performance}</div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-500 mb-1">Wynik</div>
                      <div className="text-cyan-600">{project.metrics.growth}</div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 text-center"
        >
          <p className="text-xl text-slate-600 mb-8">
            Te projekty to dowód na to, że wiemy jak tworzyć systemy, które <span className="text-slate-900">działają i zarabiają</span>.
          </p>
          <button className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white rounded-full transition-colors text-lg">
            Porozmawiajmy o Twoim projekcie
          </button>
        </motion.div>
      </div>
    </section>
  );
}