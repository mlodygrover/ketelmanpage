import { Mail, Phone, MapPin, Send } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";

export function Contact() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left side - Contact info */}
          <div>
            <div className="inline-block px-4 py-2 bg-purple-100 rounded-full text-purple-600 text-sm mb-4">
              Kontakt
            </div>
            <h2 className="text-4xl md:text-5xl mb-6 text-slate-900">
              Gotowy na rozmowę o Twoim projekcie?
            </h2>
            <p className="text-xl text-slate-600 mb-12 leading-relaxed">
              Niezależnie od tego, czy masz gotową specyfikację, czy dopiero pomysł - 
              porozmawiajmy. Pierwsza konsultacja jest zawsze <span className="text-purple-600">bezpłatna i niezobowiązująca</span>.
            </p>

            <div className="space-y-6 mb-12">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 mb-1">Email</div>
                  <a href="mailto:kontakt@twojfirma.pl" className="text-lg text-slate-900 hover:text-purple-600 transition-colors">
                    kontakt@twojfirma.pl
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 mb-1">Telefon</div>
                  <a href="tel:+48123456789" className="text-lg text-slate-900 hover:text-purple-600 transition-colors">
                    +48 123 456 789
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 mb-1">Siedziba</div>
                  <div className="text-lg text-slate-900">
                    Warszawa, Polska<br />
                    <span className="text-sm text-slate-500">Działamy też zdalnie w całej Europie</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-gradient-to-br from-purple-50 to-cyan-50 rounded-2xl border border-purple-100">
              <h3 className="text-lg mb-2 text-slate-900">Co się stanie po wysłaniu formularza?</h3>
              <ul className="space-y-2 text-slate-700">
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-1">→</span>
                  <span>Oddzwonimy w ciągu 24h roboczych</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-1">→</span>
                  <span>Umówimy wstępną konsultację (online lub stacjonarnie)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 mt-1">→</span>
                  <span>Przedstawimy wstępną wycenę i timeline projektu</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Right side - Contact form */}
          <div className="bg-white p-8 rounded-3xl shadow-2xl border border-slate-200">
            <h3 className="text-2xl mb-6 text-slate-900">
              Wyślij wiadomość
            </h3>
            <form className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-2 text-slate-700">Imię i nazwisko</label>
                  <Input 
                    type="text" 
                    placeholder="Jan Kowalski"
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-2 text-slate-700">Firma</label>
                  <Input 
                    type="text" 
                    placeholder="Twoja Firma Sp. z o.o."
                    className="w-full"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm mb-2 text-slate-700">Email</label>
                <Input 
                  type="email" 
                  placeholder="jan.kowalski@firma.pl"
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm mb-2 text-slate-700">Telefon</label>
                <Input 
                  type="tel" 
                  placeholder="+48 123 456 789"
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm mb-2 text-slate-700">Budżet projektu</label>
                <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                  <option>Wybierz przedział</option>
                  <option>Do 50 000 PLN</option>
                  <option>50 000 - 100 000 PLN</option>
                  <option>100 000 - 250 000 PLN</option>
                  <option>Powyżej 250 000 PLN</option>
                  <option>Nie jestem pewien</option>
                </select>
              </div>

              <div>
                <label className="block text-sm mb-2 text-slate-700">Opisz swój projekt</label>
                <Textarea 
                  placeholder="Opowiedz nam o swoim pomyśle, celach biznesowych i oczekiwaniach..."
                  className="w-full min-h-32"
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white py-6 text-lg"
              >
                Wyślij zapytanie
                <Send className="ml-2 w-5 h-5" />
              </Button>

              <p className="text-sm text-slate-500 text-center">
                Wysyłając formularz akceptujesz naszą politykę prywatności
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
