"use client";

import { motion } from "motion/react";
import { useEffect, useState } from "react";

export function CityScape() {
  const [windowStates, setWindowStates] = useState<boolean[]>([]);

  useEffect(() => {
    // Initialize random window states
    const initialStates = Array.from({ length: 80 }, () => Math.random() > 0.3);
    setWindowStates(initialStates);

    // Randomly toggle windows
    const interval = setInterval(() => {
      setWindowStates(prev => 
        prev.map(state => Math.random() > 0.95 ? !state : state)
      );
    }, 500);

    return () => clearInterval(interval);
  }, []);

  const buildings = [
    { height: 180, width: 60, windows: 12, delay: 0 },
    { height: 220, width: 50, windows: 15, delay: 0.1 },
    { height: 160, width: 70, windows: 10, delay: 0.05 },
    { height: 280, width: 55, windows: 20, delay: 0.15 },
    { height: 200, width: 65, windows: 14, delay: 0.08 },
    { height: 240, width: 60, windows: 16, delay: 0.12 },
    { height: 190, width: 50, windows: 13, delay: 0.06 },
    { height: 300, width: 70, windows: 22, delay: 0.2 },
    { height: 170, width: 55, windows: 11, delay: 0.04 },
    { height: 210, width: 60, windows: 14, delay: 0.09 },
    { height: 260, width: 65, windows: 18, delay: 0.14 },
    { height: 180, width: 50, windows: 12, delay: 0.07 },
  ];

  let windowIndex = 0;

  return (
    <div className="absolute bottom-0 left-0 right-0 h-96 overflow-hidden pointer-events-none">
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-7xl flex items-end justify-center gap-1">
        {buildings.map((building, buildingIdx) => {
          const buildingWindows = [];
          const cols = 3;
          const rows = Math.ceil(building.windows / cols);
          
          for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
              if (windowIndex < windowStates.length) {
                buildingWindows.push(windowStates[windowIndex]);
                windowIndex++;
              }
            }
          }

          return (
            <motion.div
              key={buildingIdx}
              className="relative bg-gradient-to-b from-slate-300/80 to-slate-400/90 backdrop-blur-sm border-l border-r border-slate-400/50"
              style={{
                height: `${building.height}px`,
                width: `${building.width}px`,
              }}
              initial={{ y: 100, opacity: 0 }}
              animate={{ 
                y: [0, -5, 0],
                opacity: 0.7
              }}
              transition={{
                y: {
                  duration: 3 + buildingIdx * 0.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: building.delay,
                },
                opacity: {
                  duration: 0.8,
                  delay: building.delay,
                }
              }}
            >
              {/* Building top antenna/decoration */}
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-1 h-6 bg-red-500/70">
                <motion.div
                  className="absolute top-0 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-red-500 rounded-full"
                  animate={{
                    opacity: [1, 0.3, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: buildingIdx * 0.3,
                  }}
                />
              </div>

              {/* Windows grid */}
              <div className="absolute inset-0 p-2 grid grid-cols-3 gap-2 content-start pt-6">
                {buildingWindows.map((isLit, idx) => (
                  <div
                    key={idx}
                    className={`w-full h-4 transition-all duration-500 ${
                      isLit
                        ? 'bg-yellow-400/90 shadow-lg shadow-yellow-500/60'
                        : 'bg-slate-200/40'
                    }`}
                    style={{
                      boxShadow: isLit ? '0 0 10px rgba(253, 224, 71, 0.6)' : 'none',
                    }}
                  />
                ))}
              </div>

              {/* Building entrance */}
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-12 bg-cyan-500/70" />
            </motion.div>
          );
        })}
      </div>

      {/* Ground/base */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-slate-300 to-transparent" />
      
      {/* Fog effect */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white/60 to-transparent pointer-events-none" />
    </div>
  );
}