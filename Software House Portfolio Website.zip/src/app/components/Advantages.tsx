"use client";

import { Target, Zap, Shield, Users, Rocket, TrendingUp } from "lucide-react";
import { Card } from "./ui/card";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const advantages = [
  {
    icon: Target,
    title: "Wiemy, co działa w praktyce",
    description: "Nie teoryzujemy - tworzymy rozwiązania sprawdzone w działaniu. Każde nasze narzędzie przeszło test prawdziwego biznesu.",
    gradient: "from-cyan-500 to-blue-500"
  },
  {
    icon: Zap,
    title: "Szybkość wdrożeń",
    description: "Dzięki gotowym modułom i sprawdzonym architekturom dostarczamy projekty w rekordowym czasie bez kompromisów jakościowych.",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: Shield,
    title: "Bezpieczeństwo z doświadczenia",
    description: "Nasze systemy przetwarzają prawdziwe transakcje i dane. Wiemy, jak budować bezpieczne aplikacje od podstaw.",
    gradient: "from-orange-500 to-red-500"
  },
  {
    icon: Users,
    title: "Myślimy jak użytkownik i właściciel",
    description: "Rozumiemy perspektywę biznesową - sami jesteśmy przedsiębiorcami. Tworzymy UX, który naprawdę konwertuje.",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    icon: Rocket,
    title: "Skalowalność gwarantowana",
    description: "Nasze systemy obsługują tysiące użytkowników dziennie. Projektujemy aplikacje gotowe na Twój rozwój.",
    gradient: "from-indigo-500 to-purple-500"
  },
  {
    icon: TrendingUp,
    title: "ROI od pierwszego dnia",
    description: "Każda funkcja ma uzasadnienie biznesowe. Optymalizujemy koszty i maksymalizujemy wartość dla Twojej firmy.",
    gradient: "from-yellow-500 to-orange-500"
  }
];

export function Advantages() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block px-4 py-2 bg-purple-100 rounded-full text-purple-600 text-sm mb-4"
          >
            Nasze przewagi
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl mb-4 text-slate-900"
          >
            Dlaczego warto z nami współpracować?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-slate-600 max-w-3xl mx-auto"
          >
            Nie jesteśmy typowym software house. Mamy coś, czego inni nie mają - 
            <span className="text-purple-600"> doświadczenie w prowadzeniu własnego biznesu technologicznego</span>.
          </motion.p>
        </div>

        {/* Images showcase */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid md:grid-cols-3 gap-6 mb-16"
        >
          <div className="relative h-64 rounded-2xl overflow-hidden group">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1603351130949-476794ec3dff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb2RpbmclMjBzY3JlZW58ZW58MXx8fHwxNzY3NjI1MTUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Coding"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/80 to-transparent flex items-end p-6">
              <p className="text-white">Najlepsze praktyki kodowania</p>
            </div>
          </div>
          <div className="relative h-64 rounded-2xl overflow-hidden group">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1760346546771-a81d986459ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1lZXRpbmclMjBwbGFubmluZ3xlbnwxfHx8fDE3Njc1NTUxMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Business planning"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-900/80 to-transparent flex items-end p-6">
              <p className="text-white">Strategia biznesowa</p>
            </div>
          </div>
          <div className="relative h-64 rounded-2xl overflow-hidden group">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1761818645915-260598d569a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbm5vdmF0aW9uJTIwd29ya3NwYWNlfGVufDF8fHx8MTc2NzYyNzQ0NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Innovation workspace"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-pink-900/80 to-transparent flex items-end p-6">
              <p className="text-white">Innowacyjne rozwiązania</p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {advantages.map((advantage, index) => {
            const Icon = advantage.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card 
                  className="p-8 hover:shadow-2xl transition-all duration-300 border-2 hover:border-purple-200 group cursor-pointer h-full"
                >
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${advantage.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl mb-3 text-slate-900">
                    {advantage.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {advantage.description}
                  </p>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* CTA Box */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-16 p-12 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-3xl text-center text-white shadow-2xl"
        >
          <h3 className="text-3xl md:text-4xl mb-4">
            Gotowy na projekt, który przyniesie realne rezultaty?
          </h3>
          <p className="text-xl mb-8 text-purple-100 max-w-2xl mx-auto">
            Nie musisz ryzykować z nieprzetestowanymi rozwiązaniami. Pracuj z zespołem, 
            który wie, jak tworzyć systemy generujące przychody.
          </p>
          <button className="px-8 py-4 bg-white text-purple-600 rounded-full hover:bg-purple-50 transition-colors text-lg">
            Bezpłatna konsultacja projektu
          </button>
        </motion.div>
      </div>
    </section>
  );
}