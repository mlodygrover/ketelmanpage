import { Code2, Linkedin, Github, Twitter, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-purple-500 rounded-lg flex items-center justify-center">
                <Code2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl">Ketelman</span>
            </div>
            <p className="text-slate-400 mb-6">
              Software house z doświadczeniem w prowadzeniu własnych biznesów technologicznych.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-cyan-500 rounded-lg flex items-center justify-center transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-purple-500 rounded-lg flex items-center justify-center transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-pink-500 rounded-lg flex items-center justify-center transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-green-500 rounded-lg flex items-center justify-center transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg mb-4">Usługi</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Aplikacje webowe</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Aplikacje mobilne</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">E-commerce</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Systemy SaaS</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Konsultacje IT</a></li>
            </ul>
          </div>

          {/* Technologies */}
          <div>
            <h3 className="text-lg mb-4">Technologie</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">React & Next.js</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Node.js & Python</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">AWS & Azure</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">PostgreSQL & MongoDB</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">DevOps & CI/CD</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-lg mb-4">Firma</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">O nas</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Portfolio</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Blog techniczny</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Kariera</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Kontakt</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            © 2026 Ketelman Holding & Software House. Wszystkie prawa zastrzeżone.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-slate-400 hover:text-white transition-colors">Polityka prywatności</a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">Regulamin</a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
}