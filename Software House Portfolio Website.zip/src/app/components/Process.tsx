"use client";

import { Lightbulb, Palette, Code, Rocket, LineChart, Headphones } from "lucide-react";
import { motion } from "motion/react";

const steps = [
  {
    icon: Lightbulb,
    number: "01",
    title: "Analiza i strategia",
    description: "Poznajemy Twój biznes od środka. Nie pytamy tylko o wymagania techniczne - chcemy zrozumieć Twoje cele biznesowe i modele zarobkowe.",
    color: "cyan"
  },
  {
    icon: Palette,
    number: "02",
    title: "UX/UI Design",
    description: "Projektujemy interfejsy, które konwertują. Opieramy się na danych z naszych własnych systemów - wiemy, co działa w praktyce.",
    color: "purple"
  },
  {
    icon: Code,
    number: "03",
    title: "Rozwój i implementacja",
    description: "Agile development z tygodniowymi sprintami. Widzisz postępy na żywo i możesz testować każdą funkcję przed publikacją.",
    color: "green"
  },
  {
    icon: Rocket,
    number: "04",
    title: "Wdrożenie i migracja",
    description: "Bezbolesne przejście z zero downtime. Szkolimy Twój zespół i zapewniamy pełną dokumentację techniczną.",
    color: "orange"
  },
  {
    icon: LineChart,
    number: "05",
    title: "Optymalizacja",
    description: "Monitorujemy wydajność i konwersje. Ciągle ulepszamy system na podstawie rzeczywistych danych użytkowników.",
    color: "pink"
  },
  {
    icon: Headphones,
    number: "06",
    title: "Wsparcie 24/7",
    description: "Nie zostawiamy Cię samego. Oferujemy pełne wsparcie techniczne, SLA i stałe aktualizacje bezpieczeństwa.",
    color: "indigo"
  }
];

export function Process() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block px-4 py-2 bg-slate-100 rounded-full text-slate-600 text-sm mb-4"
          >
            Nasz proces
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl mb-4 text-slate-900"
          >
            Jak pracujemy z klientami
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-slate-600 max-w-3xl mx-auto"
          >
            Proces wypracowany na dziesiątkach własnych projektów. 
            Sprawdzony, przewidywalny i przede wszystkim - skuteczny.
          </motion.p>
        </div>

        <div className="relative">
          {/* Connection line */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-200 via-purple-200 to-pink-200"></div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12 relative">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const colorClasses = {
                cyan: "bg-cyan-500 text-cyan-500",
                purple: "bg-purple-500 text-purple-500",
                green: "bg-green-500 text-green-500",
                orange: "bg-orange-500 text-orange-500",
                pink: "bg-pink-500 text-pink-500",
                indigo: "bg-indigo-500 text-indigo-500"
              };
              
              return (
                <motion.div 
                  key={index} 
                  className="relative"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  {/* Number badge */}
                  <div className="absolute -top-4 left-0 text-6xl text-slate-100 pointer-events-none">
                    {step.number}
                  </div>
                  
                  <div className="relative z-10">
                    <motion.div 
                      className={`w-16 h-16 ${colorClasses[step.color as keyof typeof colorClasses].split(' ')[0]} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <Icon className="w-8 h-8 text-white" />
                    </motion.div>
                    
                    <h3 className={`text-2xl mb-3 ${colorClasses[step.color as keyof typeof colorClasses].split(' ')[1]}`}>
                      {step.title}
                    </h3>
                    
                    <p className="text-slate-600 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Timeline CTA */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-20 p-10 bg-gradient-to-br from-slate-50 to-slate-100 rounded-3xl border-2 border-slate-200"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl md:text-3xl mb-2 text-slate-900">
                Przeciętny czas realizacji: 8-12 tygodni
              </h3>
              <p className="text-slate-600 text-lg">
                Od pierwszej rozmowy do działającego systemu w produkcji
              </p>
            </div>
            <button className="px-8 py-4 bg-slate-900 text-white rounded-full hover:bg-slate-800 transition-colors whitespace-nowrap text-lg">
              Rozpocznij projekt
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}